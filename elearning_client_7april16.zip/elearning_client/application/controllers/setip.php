<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Setip extends CI_Controller
{

#
# -----------------------------------------------------
# PRODUCT NAME:     ELEARNING
# -----------------------------------------------------
# AUTHOR:           MUGEN TEAM (@JohnnyAustorProduction)
# -----------------------------------------------------
# EMAIL:            info@mugen.co.id
# -----------------------------------------------------
# COPYRIGHT:        RESERVED BY MUGEN IT
# -----------------------------------------------------
# WEBSITE:          http://mugen.co.id
# -----------------------------------------------------
#
    private $db_error = "";
    private $prefix;

    function __construct()
    {
        parent::__construct();

        # load helper
        $this->load->helper(array('url', 'form', 'text', 'elearning', 'security', 'file', 'number', 'date'));

        # load library
        $this->load->library(array('form_validation', 'twig', 'user_agent'));

        # delimiters form validation
        $this->form_validation->set_error_delimiters('<span class="text-error"><i class="icon-info-sign"></i> ', '</span>');

        
    }


    function set_ip()
    {
        $config_db = array();
        $config_db['hostname'] = $this->input->post('ip');
        $this->config->set_item('hostname', $this->input->post('ip'));
        $this->config->db_config_update($config_db);
        //unset($this->db);
        return TRUE;
    }

    function index()
    {
        $dt = $this->input->post('ip');
        echo($dt);
        
        $this->form_validation->set_rules('ip', 'Username', 'required|callback_set_ip');
        if ($this->form_validation->run() == FALSE) {            
            redirect('setup');                
        } else {
            redirect('setup');
            
        }
        
    }
}
