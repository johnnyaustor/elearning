<?php

/* config-ip.html */
class __TwigTemplate_779b8aa79cf78c3804f8f1b68d515843a21ce3efe696c5bb6cfa544fc643b8d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Install - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"row\">
    <div class=\"module span8 offset2\">
            <div class=\"module-head\">
                <span class=\"pull-right\">Konfigurasi Alamat IP Server</span>
                <h3>Install e-learning</h3>
            </div>

            <div class=\"module-body\">
                ";
        // line 16
        echo (isset($context["error"]) ? $context["error"] : null);
        echo "

                ";
        // line 18
        echo form_open("setip/index", array("class" => "form-horizontal row-fluid"));
        echo "                    
                    <div class=\"control-group\">
                        <label class=\"control-label\">Alamat IP <span class=\"text-error\">*</span></label>
                        <div class=\"controls\">
                            <input type=\"text\" name=\"ip\" class=\"span8\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, set_value("ip"), "html", null, true);
        echo "\">
                            <br>";
        // line 23
        echo form_error("ip");
        echo "
                        </div>
                    </div>
                    <div class=\"control-group\">
                        <div class=\"controls\">
                            <button type=\"submit\" class=\"btn btn-primary\">Simpan</button>
                        </div>
                    </div>                    
                ";
        // line 31
        echo form_close();
        echo "

            </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "config-ip.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 31,  68 => 23,  64 => 22,  57 => 18,  52 => 16,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
