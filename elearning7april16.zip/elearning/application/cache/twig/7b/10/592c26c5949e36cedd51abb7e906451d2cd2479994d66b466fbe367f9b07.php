<?php

/* chart.html */
class __TwigTemplate_7b10592c26c5949e36cedd51abb7e906451d2cd2479994d66b466fbe367f9b07 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Detail Tugas - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">                    
    <div class=\"module-head\">
        ";
        // line 10
        if ((is_siswa() == false)) {
            // line 11
            echo "        <h3>";
            echo anchor(("rangkuman/index/" . (isset($context["status_id"]) ? $context["status_id"] : null)), "Rangkuman Tugas");
            echo " / Detail</h3>        
        ";
        }
        // line 13
        echo "    </div>
    <div class=\"module-body\">
        ";
        // line 15
        echo get_flashdata("tugas");
        echo "                

        <div class=\"row-fluid\">
            <div class=\"span12\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <strong>Rangkuman Tugas</strong>
                    </div>
                    <div class=\"panel-body\">
                        <div id=\"container\" style=\"min-width: 100px; height: 200px; max-width: 400px; margin: 0 auto\"></div>
                        <script>
                            \$(function () {
                                \$('#container').highcharts({
                                    chart: {
                                        plotBackgroundColor: null,
                                        plotBorderWidth: null,
                                        plotShadow: false,
                                        type: 'pie'
                                    },
                                    colors: [\"#7cb5ec\", \"#f7a35c\", \"#90ee7e\", \"#7798BF\", \"#aaeeee\", \"#ff0066\", \"#eeaaee\",\"#55BF3B\", \"#DF5353\", \"#7798BF\", \"#aaeeee\"],
                                    title: {
                                        text: ''
                                    },
                                    tooltip: {
                                        pointFormat: '{point.name}:'+ '{point.y}' + ' (<b>{point.percentage:.1f}%</b>)'
                                    },
                                    plotOptions: {
                                        pie: {
                                            allowPointSelect: true,
                                            cursor: 'pointer',
                                            dataLabels: {
                                                enabled: true,
                                                format: '<b>{point.name}</b>:{point.percentage:.1f} %',
                                                style: {
                                                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                                }
                                            }
                                        }
                                    },
                                    series: [{
                                        name: 'Brands',
                                        colorByPoint: true,
                                        data: [{
                                            name: 'Benar',
                                            y: 1
                                        }, {
                                            name: 'Salah',
                                            y: 4,
                                        }]
                                    }]
                                });                                                            
                            });
                        </script>
                        
                    </div>
                    
                </div>
            </div>
        </div>        
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "chart.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 15,  54 => 13,  48 => 11,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
