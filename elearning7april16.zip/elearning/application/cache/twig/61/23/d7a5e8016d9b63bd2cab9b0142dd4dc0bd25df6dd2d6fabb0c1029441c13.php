<?php

/* print-preview-tugas.html */
class __TwigTemplate_6123d7a5e8016d9b63bd2cab9b0142dd4dc0bd25df6dd2d6fabb0c1029441c13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo twig_escape_filter($this->env, (isset($context["string"]) ? $context["string"] : null), "html", null, true);
        echo "
";
    }

    public function getTemplateName()
    {
        return "print-preview-tugas.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,);
    }
}
