<?php

/* laporan.html */
class __TwigTemplate_c545aaf2f7cc33257c971919bb4a94b882d1db87c63049e554c9a467f7e3a778 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout-private.html");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout-private.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "Detail Tugas - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "<div class=\"module\">
    <div class=\"module-head\">
        ";
        // line 10
        if ((is_siswa() == false)) {
            // line 11
            echo "        <h3>";
            echo anchor(("rangkuman/index/" . (isset($context["status_id"]) ? $context["status_id"] : null)), "Rangkuman Tugas");
            echo " / Detail</h3>        
        ";
        }
        // line 13
        echo "    </div>
    <div class=\"module-body\">
        ";
        // line 15
        echo get_flashdata("tugas");
        echo "                

        <div class=\"row-fluid\">
            <div class=\"span12\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <strong>Rangkuman Tugas</strong>
                    </div>
                    <div class=\"panel-body\">
                        <table class=\"table table-condensed\">
                            <thead>
                                <tr bgcolor=\"#fbfbfb\">
                                    <th>ID Tugas</th>
                                    <th>Jumlah Soal</th>
\t\t\t                        <th>Jumlah Siswa Mengerjakan</th>                        
\t\t\t                        <th>Benar</th>
\t\t\t                        <th>salah</th>
\t\t\t                        <th>Jumlah Nilai</th>
\t\t\t                        <th>Rata Nilai</th>
                                </tr>
                            </thead>
                            <tbody>
                            \t<tr align=\"center\">
\t\t\t                        <td>";
        // line 38
        echo twig_escape_filter($this->env, (isset($context["id_tugas"]) ? $context["id_tugas"] : null), "html", null, true);
        echo "</td>
\t\t\t                        <td>";
        // line 39
        echo twig_escape_filter($this->env, (isset($context["jumlah_soal"]) ? $context["jumlah_soal"] : null), "html", null, true);
        echo "</td>
\t\t\t                        <td>";
        // line 40
        echo twig_escape_filter($this->env, (isset($context["total_siswa"]) ? $context["total_siswa"] : null), "html", null, true);
        echo "</td>                        
\t\t\t                        <td>";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["benar"]) ? $context["benar"] : null), "html", null, true);
        echo "</td>
\t\t\t                        <td>";
        // line 42
        echo twig_escape_filter($this->env, (isset($context["salah"]) ? $context["salah"] : null), "html", null, true);
        echo "</td>
\t\t\t                        <td>";
        // line 43
        echo twig_escape_filter($this->env, (isset($context["nilai"]) ? $context["nilai"] : null), "html", null, true);
        echo "</td>
\t\t\t                        <td>";
        // line 44
        echo twig_escape_filter($this->env, (isset($context["rata_nilai"]) ? $context["rata_nilai"] : null), "html", null, true);
        echo "</td>
\t\t\t                    </tr>                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class=\"row-fluid\">
            <div class=\"span12\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <strong>Rangkuman Pertanyaan</strong>
                    </div>
                    <div class=\"panel-body\">
                        <table class=\"table\">
                            <thead>
                                <tr>
                                    <th width=\"3%\">ID</th>
\t\t\t                        <th>Pertanyaan</th>
\t\t\t                        <th width=\"3%\">Benar</th>
\t\t\t                        <th width=\"3%\">Salah</th>
                                    <th width=\"20%\">Diagram</th>
                                </tr>
                            </thead>
                            <tbody>
                            \t";
        // line 71
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rangkuman_pertanyaan"]) ? $context["rangkuman_pertanyaan"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 72
            echo "                            \t<tr>
\t\t\t                        <td><b>";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "</b></td>
\t\t\t                        <td>
\t\t\t                        \t<div class=\"pertanyaan\">\t\t\t\t                           
\t\t\t\t                            ";
            // line 76
            echo html_entity_decode($this->getAttribute((isset($context["p"]) ? $context["p"] : null), "pertanyaan"));
            echo "
\t\t\t\t                        </div>
\t\t\t\t                        <div class=\"pilihan\">
\t\t\t\t                        \t<table class=\"table table-condensed table-striped\">
                                \t\t\t\t<thead>
\t\t\t\t\t                                <tr>
\t\t\t\t\t                                    <th width=\"5%\">ID</th>
\t\t\t\t\t\t\t\t                        <th>Pilihan</th>
\t\t\t\t\t\t\t\t                        <th width=\"5%\">Dipilih</th>
\t\t\t\t\t                                </tr>
\t\t\t\t\t                            </thead>
                                \t\t\t\t<tbody>
                                \t\t\t\t\t";
            // line 88
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["rangkuman_pilihan"]) ? $context["rangkuman_pilihan"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["pil"]) {
                // line 89
                echo "                                \t\t\t\t\t";
                if (($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "pertanyaan_id") == $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"))) {
                    // line 90
                    echo "                            \t\t\t\t\t\t<tr ";
                    echo ((($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "kunci") == 1)) ? ("class=\"success\"") : (""));
                    echo ">
\t\t\t\t                                    \t<td>";
                    // line 91
                    echo html_entity_decode($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "ide"));
                    echo "</td>
\t\t\t\t                                    \t<td>";
                    // line 92
                    echo html_entity_decode($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "konten"));
                    echo "
\t\t\t\t                                    \t\t";
                    // line 93
                    if (($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "kunci") == 1)) {
                        // line 94
                        echo "\t\t\t\t                                            <b class=\"text-warning\"><i class=\"icon-star\"></i> Kunci Jawaban</b>
\t\t\t\t                                            ";
                    }
                    // line 96
                    echo "\t\t\t\t                                    \t</td>                        
\t\t\t\t                                    \t<td align=center>";
                    // line 97
                    echo twig_escape_filter($this->env, html_entity_decode($this->getAttribute((isset($context["pil"]) ? $context["pil"] : null), "dipilih")), "html", null, true);
                    echo "</td>
\t\t\t\t                                    </tr>
\t\t\t\t                                    ";
                }
                // line 99
                echo "\t\t\t\t                                    \t\t\t\t                                    \t
                                \t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pil'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 100
            echo "                                \t\t\t\t\t
                                \t\t\t\t</tbody>
                                \t\t\t</table>
\t\t\t\t                        </div>
\t\t\t                        </td>
\t\t\t                        <td>";
            // line 105
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "benar"), "html", null, true);
            echo "</td>                        
\t\t\t                        <td>";
            // line 106
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "salah"), "html", null, true);
            echo "</td>
                                    <td>
                                        <div id=\"container";
            // line 108
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "\" style=\"min-width: 100px; height: 200px; max-width: 200px; margin: 0 auto\"></div>
                                        <script>
                                            \$(function () {
                                                \$('#container";
            // line 111
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "id"), "html", null, true);
            echo "').highcharts({
                                                    chart: {
                                                        plotBackgroundColor: null,
                                                        plotBorderWidth: null,
                                                        plotShadow: false,
                                                        type: 'pie'
                                                    },
                                                    colors: [\"#7cb5ec\", \"#f7a35c\", \"#90ee7e\", \"#7798BF\", \"#aaeeee\", \"#ff0066\", \"#eeaaee\",\"#55BF3B\", \"#DF5353\", \"#7798BF\", \"#aaeeee\"],                                    
                                                    title: { text: '' },
                                                    tooltip: {
                                                        pointFormat: '{point.name}:'+ '{point.y}' + ' (<b>{point.percentage:.1f}%</b>)'
                                                    },
                                                    plotOptions: {
                                                        pie: {
                                                            allowPointSelect: true,
                                                            cursor: 'pointer',
                                                            dataLabels: {
                                                                enabled: true,
                                                                format: '<b>{point.name}</b>:{point.percentage:.1f} %',
                                                                style: {
                                                                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                                                }
                                                            }
                                                        }
                                                    },
                                                    series: [{
                                                        name: 'Nilai',
                                                        colorByPoint: true,
                                                        data: [{
                                                            name: 'Benar',
                                                            y: ";
            // line 141
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "benar"), "html", null, true);
            echo ",
                                                            sliced: true
                                                        }, {
                                                            name: 'Salah',
                                                            y: ";
            // line 145
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : null), "salah"), "html", null, true);
            echo ",
                                                        }]
                                                    }]
                                                });                                                            
                                            });
                                        </script>
                                    </td>
\t\t\t                    </tr>
\t\t\t                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 154
        echo "\t\t\t                    <tr>
                                \t<td colspan=2 align=right><B>TOTAL JAWABAN</B></td>
\t\t\t\t                    <td>";
        // line 156
        echo twig_escape_filter($this->env, (isset($context["total_benar"]) ? $context["total_benar"] : null), "html", null, true);
        echo "</td>
\t\t\t\t                    <td>";
        // line 157
        echo twig_escape_filter($this->env, (isset($context["total_salah"]) ? $context["total_salah"] : null), "html", null, true);
        echo "</td>
                                </tr>                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "laporan.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  293 => 157,  289 => 156,  285 => 154,  270 => 145,  263 => 141,  230 => 111,  224 => 108,  219 => 106,  215 => 105,  208 => 100,  201 => 99,  195 => 97,  192 => 96,  188 => 94,  186 => 93,  182 => 92,  178 => 91,  173 => 90,  170 => 89,  166 => 88,  151 => 76,  145 => 73,  142 => 72,  138 => 71,  108 => 44,  104 => 43,  100 => 42,  96 => 41,  92 => 40,  88 => 39,  84 => 38,  58 => 15,  54 => 13,  48 => 11,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,);
    }
}
