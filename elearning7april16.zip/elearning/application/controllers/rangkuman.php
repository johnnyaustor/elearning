<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rangkuman extends MY_Controller
{

#
# -----------------------------------------------------
# PRODUCT NAME:     ELEARNING
# -----------------------------------------------------
# AUTHOR:           MUGEN TEAM (@JohnnyAustorProduction)
# -----------------------------------------------------
# EMAIL:            info@mugen.co.id
# -----------------------------------------------------
# COPYRIGHT:        RESERVED BY MUGEN IT
# -----------------------------------------------------
# WEBSITE:          http://mugen.co.id
# -----------------------------------------------------
#
    function __construct()
    {
        parent::__construct();

        must_login();
    }

    private function formatData($val)
    {
        # cari pembuatnya
        if (!empty($val['pengajar_id'])) {
            $pengajar = $this->pengajar_model->retrieve($val['pengajar_id']);
            $val['pembuat'] = $pengajar;
            if (is_admin()) {
                $val['pembuat']['link_profil'] = site_url('pengajar/detail/'.$pengajar['status_id'].'/'.$pengajar['id']);
            } else {
                $val['pembuat']['link_profil'] = site_url('pengajar/detail/'.$pengajar['id']);
            }
        }

        # cari tugas kelas
        $tugas_kelas = $this->tugas_model->retrieve_all_kelas($val['id']);
        foreach ($tugas_kelas as $mk) {
            $kelas = $this->kelas_model->retrieve($mk['kelas_id']);
            $val['tugas_kelas'][] = $kelas;
        }

        # cari matapelajarannya
        $val['mapel'] = $this->mapel_model->retrieve($val['mapel_id']);

        # type label
        if ($val['type_id'] == 1) {
            $val['type_label'] = 'Upload';
        }
        if ($val['type_id'] == 2) {
            $val['type_label'] = 'Essay';
        }
        if ($val['type_id'] == 3) {
            $val['type_label'] = 'Ganda';
        }

        return $val;
    }

    function index($segment_3 = '')
    {    	

    	# jika ada post filter
        if ($this->form_validation->run('tugas/filter') == true) {
            $pembuat = $this->input->post('pembuat', TRUE);

            # cari id pengajar
            $pengajar_id = array();
            if (!empty($pembuat)) {
                foreach ($this->pengajar_model->retrieve_all_by_name($pembuat) as $val) {
                    $pengajar_id[] = $val['id'];
                }

                if (empty($pengajar_id)) {
                    $pengajar_id[] = 0;
                }
            }

            $filter = array(
                'judul'       => $this->input->post('judul', true),
                'info'        => $this->input->post('info', true),
                'pengajar_id' => $pengajar_id,
                'pembuat'     => $pembuat,
                'mapel_id'    => $this->input->post('mapel_id', true),
                'kelas_id'    => $this->input->post('kelas_id', true),
                'type'        => $this->input->post('type', true),
                'status'      => $this->input->post('status', true),
            );

            $this->session->set_userdata('filter_tugas', $filter);
        }

        $filter = $this->session->userdata('filter_tugas');
        if (empty($filter)) {
            $filter = array(
                'judul'       => '',
                'info'        => '',
                'pengajar_id' => array(),
                'pembuat'     => '',
                'mapel_id'    => array(),
                'kelas_id'    => array(),
                'type'        => 3,
                'status'      => array()
            );
        }

        $data['filter'] = $filter;

        # ambil semua data tugas
        $retrieve_all_tugas = $this->tugas_model->retrieve_all(
            20,
            1,
            $filter['mapel_id'],
            $filter['pengajar_id'],
            3,
            $filter['kelas_id'],
            $filter['judul'],
            $filter['info'],
            $filter['status']
        );

        # format array data
        $results = array();
        foreach ($retrieve_all_tugas['results'] as $key => $val) {
            $results[$key] = $this->formatData($val);
        }

        $data['tugas']      = $results;
        $data['pagination'] = $this->pager->view($retrieve_all_tugas, 'rangkuman/index/');
        $data['kelas']      = $this->kelas_model->retrieve_all_child();
        $data['mapel']      = $this->mapel_model->retrieve_all_mapel();

        # panggil colorbox
        $html_js = load_comp_js(array(
            base_url('assets/comp/colorbox/jquery.colorbox-min.js'),
            base_url('assets/comp/colorbox/act-tugas.js')
        ));
        $data['comp_js']  = $html_js;
        $data['comp_css'] = load_comp_css(array(base_url('assets/comp/colorbox/colorbox.css')));

        $this->twig->display('list-rangkuman.html', $data);
    }

    function filter()
    {
        #variable
        $rk_jawaban=array();

        $this->load->database();
        $datas   = $this->db->get('siswa');
        $siswa  = $datas->result_array();

        $this->db->where('type_id',3);
        $tugas  = $this->db->get('tugas')->result_array();

        foreach ($tugas as $key_t => $value_t) {
            echo($key_t."=".$value_t['judul']); echo"<br>";
            foreach ($siswa as $sn => $sv) {
                # cari history
                $history_id = 'history-mengerjakan-' . $sv['id'] . '-'.$value_t['id'];
                $history    = retrieve_field($history_id);

                if (!empty($history)) {
                    $history_value   = json_decode($history['value'], 1);
                    $history = $history_value;
                    
                    if (empty($rk_jawaban[$key_t])) {
                        $rk_jawaban[$key_t] = array(
                            "benar" => $history['jml_benar'],
                            "salah" => $history['jml_salah'],);
                    } else {
                        $rk_jawaban[$key_t]['benar'] += $history['jml_benar'];
                        $rk_jawaban[$key_t]['salah'] += $history['jml_salah'];
                    }
                    
                }
            }                      
        }

        
        #menampilkan jumlah jawaban
        foreach (array_sort($rk_jawaban,"salah",SORT_ASC) as $key => $value) {
            echo("jumlah Benar = ".$value['benar'] );
            echo(" | jumlah Salah = ".$value['salah'] );
            echo"<br>"; 
        }
        
    }

    function laporan($id_tugas='')
    {
        $data['nilai'] = 0;
        $data['benar'] = "";
        $data['salah'] = "";
        $data['id_tugas'] = "";
        $data['total_siswa'] = 0;
        $rk_soal = array();
        
        $this->load->database();
        $datas   = $this->db->get('siswa');
        $siswa  = $datas->result_array();

        $jml =0;
        $bnr=0; 
        $slh=0;
        $dipilih;
        $rk_pilihan=array();
        $rk_tidak_pilihan=0;
        $id;


        foreach ($siswa as $key) {
            # cari history
            $history_id = 'history-mengerjakan-' . $key['id'] . '-'.$id_tugas;
            $history    = retrieve_field($history_id);

            if (!empty($history)) {
                $history_value   = json_decode($history['value'], 1);
                $history = $history_value;                

                $data['total_siswa'] += 1;
                $data['nilai'] = number_format($data['nilai'] + $history['nilai'],2);
                               
                # count pertanyaan
                $jml = 0;
                # Rangkuman Tugas
                foreach ($history['pertanyaan'] as $i) { 
                    $jml = $jml + 1; 
                    
                    if (get_jawaban($history['jawaban'], $i['id']) == get_kunci_pilihan($i['pilihan'])) {
                        $data['benar'] = $data['benar'] + 1;                                            
                    } else {
                        $data['salah'] = $data['salah'] + 1;                        
                    }                
                    
                }

                # Rangkuman Pertanyaan
                foreach ($history['pertanyaan'] as $i) { 
                    $jawaban = get_jawaban($history['jawaban'], $i['id']);
                    $kunci = get_kunci_pilihan($i['pilihan']);

                    if (empty($rk_soal[$i['id']])) {
                        if ($jawaban == $kunci) {
                              $rk_soal[$i['id']] = array('id' => $i['id'],'pertanyaan' => $i['pertanyaan'],
                                'benar' => $bnr+1,'salah' => $slh,);                     
                        } else {
                            $rk_soal[$i['id']] = array('id' => $i['id'], 'pertanyaan' => $i['pertanyaan'],
                                'benar' => $bnr,'salah' => $slh+1,);  
                        }
                        
                    } else {
                        if ($jawaban == $kunci) {
                            $rk_soal[$i['id']]['benar']+=1; $rk_soal[$i['id']]['salah']+=0;
                        } else {
                            $rk_soal[$i['id']]['benar']+=0; $rk_soal[$i['id']]['salah']+=1;  
                        }
                    }

                    #rangkuman jawaban 
                    foreach ($i['pilihan'] as $pil) {                            

                        if(is_pilih($history['jawaban'],$i['id'],$pil['id'])== true){
                            if(empty($rk_pilihan[$pil['id']])){
                                $rk_pilihan[$pil['id']] = array(
                                'pertanyaan_id' => $pil['pertanyaan_id'],
                                'ide' => $pil['id'],
                                'konten' => $pil['konten'],
                                'kunci' => $pil['kunci'],
                                'dipilih' => 1);
                            } else {                                    
                                $rk_pilihan[$pil['id']]['dipilih'] += 1;
                            }
                                                                                            
                        }else{
                            if(empty($rk_pilihan[$pil['id']])){
                                $rk_pilihan[$pil['id']] = array(
                                'pertanyaan_id' => $pil['pertanyaan_id'],
                                'ide' => $pil['id'],
                                'konten' => $pil['konten'],
                                'kunci' => $pil['kunci'],
                                'dipilih' => 0);
                            } else {
                                
                                $rk_pilihan[$pil['id']]['dipilih'] += 0;
                            }
                            $rk_tidak_pilihan +=1;
                        }

                    }
                }

                

                $arr = array($history['tugas']);            
                $data['id_tugas'] = $arr[0]['judul'];                

            }

        }
        

        array_multisort($rk_pilihan);
        array_multisort($rk_soal);

        $data['jumlah_soal'] = $jml;
        if(!empty($data['nilai'])){
        	$data['rata_nilai'] = number_format($data['nilai']/$data['total_siswa'],2);
    	}
        $data['rangkuman_pertanyaan'] = $rk_soal;
        $data['rangkuman_pilihan'] = $rk_pilihan;
        
        $data['total_benar'] =0;
    	$data['total_salah'] =0;
        foreach ($rk_soal as $key) {
        	$data['total_benar'] +=$key['benar'];
        	$data['total_salah'] +=$key['salah'];
        }
        
        # panggil colorbox
        $html_js = load_comp_js(array(
            base_url('assets/themes/default/scripts/highcharts.js'),
            base_url('assets/comp/colorbox/jquery.colorbox-min.js'),
            base_url('assets/comp/colorbox/act-pengajar.js')
        ));
        $data['comp_js']  = $html_js;
        $data['comp_css'] = load_comp_css(array(base_url('assets/comp/colorbox/colorbox.css')));
        if (is_siswa() == false) {
        	$this->twig->display('laporan.html', $data);
        } else {
        	redirect('welcome');
        }
        
    }

    function bak_lap($id_tugas){
    	
    	$data['nilai'] = "";
        $data['benar'] = "";
        $data['salah'] = "";
        $data['id_tugas'] = "";
        $data['total_siswa'] = "";
        //$rk_soal[] = array();

        $this->load->database();
        $datas   = $this->db->get('siswa');
        $siswa  = $datas->result_array();

        $bnr=0; 
        $slh=0;
        $dipilih;
        $rk_pilihan=array();
        $rk_tidak_pilihan=0;
        $id;

        foreach ($siswa as $key) {
            # cari history
            $history_id = 'history-mengerjakan-' . $key['id'] . '-'.$id_tugas;
            $history    = retrieve_field($history_id);

            if (!empty($history)) {
                $history_value   = json_decode($history['value'], 1);
                $history = $history_value;
                echo($history['mulai']);printf("<br>");                
                echo($history['selesai']);printf("<br>");
                echo($history['nilai']);printf("<br>");

                $data['total_siswa'] += 1;
                $data['nilai'] = $data['nilai'] + $history['nilai'];
                               
                # count pertanyaan
                $jml = 0;
                # Rangkuman Tugas
                foreach ($history['pertanyaan'] as $i) { 
                    $jml = $jml + 1; 
                    echo('pertanyaan ke-'.$i['id'].':'.get_jawaban($history['jawaban'], $i['id']));echo '='.get_kunci_pilihan($i['pilihan']);echo("<br>");
                    if (get_jawaban($history['jawaban'], $i['id']) == get_kunci_pilihan($i['pilihan'])) {
                        $data['benar'] = $data['benar'] + 1;                                            
                    } else {
                        $data['salah'] = $data['salah'] + 1;                        
                    }                
                    
                }
                # Rangkuman Pertanyaan
                foreach ($history['pertanyaan'] as $i) { 
                    $jawaban = get_jawaban($history['jawaban'], $i['id']);
                    $kunci = get_kunci_pilihan($i['pilihan']);

                    if (empty($rk_soal[$i['id']])) {
                        if ($jawaban == $kunci) {
                              $rk_soal[$i['id']] = array('id' => $i['id'],'pertanyaan' => $i['pertanyaan'],
                                'benar' => $bnr+1,'salah' => $slh,);                     
                        } else {
                            $rk_soal[$i['id']] = array('id' => $i['id'], 'pertanyaan' => $i['pertanyaan'],
                                'benar' => $bnr,'salah' => $slh+1,);  
                        }
                        
                    } else {
                        if ($jawaban == $kunci) {
                            $rk_soal[$i['id']]['benar']+=1; $rk_soal[$i['id']]['salah']+=0;
                        } else {
                            $rk_soal[$i['id']]['benar']+=0; $rk_soal[$i['id']]['salah']+=1;  
                        }
                    }

                    #rangkuman jawaban 
                    foreach ($i['pilihan'] as $pil) {
                                                
                        //if (empty($rk_pilihan[$i["id"]])) {
                            

                            if(is_pilih($history['jawaban'],$i['id'],$pil['id'])== true){
                                if(empty($rk_pilihan[$pil['id']])){
                                    $rk_pilihan[$pil['id']] = array(
                                    'pertanyaan_id' => $pil['pertanyaan_id'],
                                    'ide' => $pil['id'],
                                    'konten' => $pil['konten'],
                                    'kunci' => $pil['kunci'],
                                    'dipilih' => 1);
                                } else {                                    
                                    $rk_pilihan[$pil['id']]['dipilih'] += 1;
                                }
                                                                                                
                            }else{
                                if(empty($rk_pilihan[$pil['id']])){
                                    $rk_pilihan[$pil['id']] = array(
                                    'pertanyaan_id' => $pil['pertanyaan_id'],
                                    'ide' => $pil['id'],
                                    'konten' => $pil['konten'],
                                    'kunci' => $pil['kunci'],
                                    'dipilih' => 0);
                                } else {
                                    
                                    $rk_pilihan[$pil['id']]['dipilih'] += 0;
                                }
                                $rk_tidak_pilihan +=1;
                            }
                            
                            
                        //} else {
                            

                        //}
                    }
                }

                

                $arr = array($history['tugas']);            
                $data['id_tugas'] = $arr[0]['judul'];

                echo 'jumlah soal = '.$jml; 

                echo("<br>");echo("<br>");

            }

        }

        foreach ($rk_pilihan as $key) {
            echo($key['ide'].":".$key['dipilih']);echo("<br>");
        }

        array_multisort($rk_pilihan);
        array_multisort($rk_soal);
        //var_dump($rk_pilihan);echo "<br>"."<br>"."<br>";
        
        //echo($dipilih);
        echo("<br>"."<B>RANGKUMAN TUGAS</B>");
        echo "<table border=1 width=30%>
                <thead align=center>
                    <tr>
                        <th>ID Tugas</th>
                        <th>Jumlah Siswa</th>                        
                        <th>Jumlah Benar</th>
                        <th>jumlah salah</th>
                        <th>Jumlah Nilai</th>
                        <th>Rata Nilai</th>
                    </tr>
                </thead>
                <tbody align=center>
                    <tr>
                        <td>".$data['id_tugas']."</td>
                        <td>".$data['total_siswa']."</td>                        
                        <td>".$data['benar']."</td>
                        <td>".$data['salah']."</td>
                        <td>".$data['nilai']."</td>
                        <td>".number_format($data['nilai']/$data['total_siswa'],2)."</td>
                    </tr>
                </tbody>
            </table>";
        echo('ID Tugas      = '.$data['id_tugas']);echo("<br>");
        echo('jumlah nilai  = '.$data['nilai']);echo("<br>");
        echo('jumlah benar  = '.$data['benar']);echo("<br>");
        echo('jumlah salah  = '.$data['salah']);echo("<br>");

        //echo(json_encode($rk_soal));
        $total_benar=0;
        $total_salah=0;
        echo("<br>"."<B>RANGKUMAN PERTANYAAN</B>");
        echo "<table border=1 width=50%>
                <thead align=center>
                    <tr>
                        <th>ID Pertanyaan</th>
                        <th>Pertanyaan</th>
                        <th>Jumlah Benar</th>
                        <th>jumlah salah</th>
                    </tr>
                </thead>
                <tbody align=center>";
        foreach ($rk_soal as $key) {
            echo "<tr>
                    <td>".$key['id']."</td>
                    <td align=left>".$key['pertanyaan']."
                        <table border=1 width=100%>
                            <th>ID</th>
                            <th>pilihan</th>
                            <th>jumlah dipilih</th>";
                            foreach ($rk_pilihan as $pil) {
                                if($pil['kunci']==1){$id="*";}else{$id="";}
                                if ($pil['pertanyaan_id']==$key['id']) {
                                    echo "<tr>
                                    <td>".$pil['ide']."<br>".$id."</td>
                                    <td>".$pil['konten']."</td>                        
                                    <td align=center>".$pil['dipilih']."</td>
                                    </tr>";
                                }
                            }
            echo"       </table>
                    </td>
                    <td>".$key['benar']."</td>
                    <td>".$key['salah']."</td>
                </tr>";
            $total_benar += $key['benar'];
            $total_salah += $key['salah'];
        }
        echo "<tr>
                    <td colspan=2 align=right><B>TOTAL JAWABAN</B></td>
                    <td>".$total_benar."</td>
                    <td>".$total_salah."</td>
                </tr>";
        echo "</tbody>
            </table>";
    }

    function print_preview()
    {
    	$data['string'] = "ini isi dari string";
    	$this->load->library('html2pdf');
	    $this->html2pdf->folder('./assets/pdfs/');
	    $this->html2pdf->filename('Report.pdf');
	    $this->html2pdf->paper('a4', 'portrait');
	    $html = $this->load->view('default/print-preview-tugas.php', $data, true);
		$this->html2pdf->html($html);
		$this->html2pdf->create();
    }

    function chart()
    {
        $data['nilai1'] = 10;
        $data['nilai2'] = 20;

        # panggil colorbox
        $html_js = load_comp_js(array(
            base_url('assets/themes/default/scripts/highcharts.js'),            
        ));
        $data['comp_js']  = $html_js;

        $this->twig->display('chart.html',$data,true);
    }

}