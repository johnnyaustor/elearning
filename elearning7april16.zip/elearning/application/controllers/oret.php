<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Oret extends MY_Controller
{

#
# -----------------------------------------------------
# PRODUCT NAME:     ELEARNING
# -----------------------------------------------------
# AUTHOR:           MUGEN TEAM (@JohnnyAustorProduction)
# -----------------------------------------------------
# EMAIL:            info@mugen.co.id
# -----------------------------------------------------
# COPYRIGHT:        RESERVED BY MUGEN IT
# -----------------------------------------------------
# WEBSITE:          http://mugen.co.id
# -----------------------------------------------------
#
	public function tampil()
	{
		$tugas = $this->tugas_model->retrieve_pertanyaan('17');
		echo "<img class=\"img-polaroid\" src='". base_url('/userfiles/images/'.$tugas['foto'])."' height=\"30\">";
		echo $tugas['urutan'];
	}

	public function wm()
	{

		$config['source_image'] = base_url('/userfiles/images/pertanyaan-1-1.jpg');
		$config['width'] = 75;
		$config['height'] = 50;
		$config['wm_text'] = 'Copyright 2016 - JAP';
		$config['wm_type'] = 'text';
		$config['wm_opacity'] = 50;
		$config['wm_font_size'] = '16';
		$config['wm_font_color'] = 'ffffff';
		$config['wm_vrt_alignment'] = 'bottom';
		$config['wm_hor_alignment'] = 'center';
		$config['wm_padding'] = '20';

		$this->load->library('image_lib', $config);
		$this->image_lib->watermark();
		if (! $this->image_lib->watermark()) {
			$this->image_lib->display_errors();
		}
		echo "<img src=".$config['source_image'].">";		
	}
}